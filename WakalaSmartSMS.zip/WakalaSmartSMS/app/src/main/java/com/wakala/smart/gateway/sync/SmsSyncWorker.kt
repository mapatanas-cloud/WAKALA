package com.wakala.smart.gateway.sync

import android.content.Context
import android.util.Log
import androidx.work.*
import com.wakala.smart.gateway.data.SmsRepository
import java.util.concurrent.TimeUnit

class SmsSyncWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val TAG = "SmsSyncWorker"
        const val WORK_NAME_IMMEDIATE = "sms_sync_immediate"
        const val WORK_NAME_PERIODIC = "sms_sync_periodic"

        fun scheduleImmediateSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<SmsSyncWorker>()
                .setConstraints(constraints)
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    WorkRequest.MIN_BACKOFF_MILLIS,
                    TimeUnit.MILLISECONDS
                )
                .build()

            WorkManager.getInstance(context)
                .enqueueUniqueWork(
                    WORK_NAME_IMMEDIATE,
                    ExistingWorkPolicy.KEEP,
                    request
                )

            Log.d(TAG, "Immediate sync scheduled")
        }

        fun schedulePeriodicSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<SmsSyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    WorkRequest.MIN_BACKOFF_MILLIS,
                    TimeUnit.MILLISECONDS
                )
                .build()

            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(
                    WORK_NAME_PERIODIC,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request
                )

            Log.d(TAG, "Periodic sync scheduled (every 15 min)")
        }

        fun cancelAll(context: Context) {
            WorkManager.getInstance(context).cancelAllWork()
        }
    }

    override suspend fun doWork(): Result {
        Log.d(TAG, "Starting SMS sync work")

        return try {
            val repository = SmsRepository(applicationContext)

            // Sync pending messages
            val (pendingSuccess, pendingFail) = repository.syncAllPending()
            Log.d(TAG, "Pending sync: $pendingSuccess sent, $pendingFail failed")

            // Retry previously failed (up to 3 retries)
            val (retrySuccess, retryFail) = repository.retryFailed()
            Log.d(TAG, "Retry sync: $retrySuccess sent, $retryFail still failing")

            // Clean up old sent messages
            repository.cleanOldMessages(30)

            if (pendingFail > 0 && pendingSuccess == 0) {
                Log.w(TAG, "All sends failed — retrying later")
                Result.retry()
            } else {
                Result.success()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Sync worker error", e)
            Result.retry()
        }
    }
}
