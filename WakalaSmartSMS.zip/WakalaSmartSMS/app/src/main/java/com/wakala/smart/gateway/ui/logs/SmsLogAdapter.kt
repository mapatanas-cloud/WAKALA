package com.wakala.smart.gateway.ui.logs

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.wakala.smart.gateway.R
import com.wakala.smart.gateway.data.local.entities.SmsEntity
import com.wakala.smart.gateway.data.local.entities.SmsStatus
import com.wakala.smart.gateway.databinding.ItemSmsLogBinding
import java.text.SimpleDateFormat
import java.util.*

class SmsLogAdapter : ListAdapter<SmsEntity, SmsLogAdapter.ViewHolder>(DIFF_CALLBACK) {

    private val dateFormat = SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemSmsLogBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemSmsLogBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(sms: SmsEntity) {
            binding.tvSender.text = sms.sender
            binding.tvMessage.text = sms.message
            binding.tvTimestamp.text = dateFormat.format(Date(sms.timestamp))

            val (label, colorRes) = when (sms.status) {
                SmsStatus.SENT -> Pair("SENT", R.color.status_sent)
                SmsStatus.PENDING -> Pair("PENDING", R.color.status_pending)
                SmsStatus.FAILED -> Pair("FAILED", R.color.status_failed)
                SmsStatus.SYNCING -> Pair("SYNCING", R.color.status_pending)
                else -> Pair(sms.status.uppercase(), R.color.status_pending)
            }
            binding.tvStatus.text = label
            binding.tvStatus.setTextColor(ContextCompat.getColor(binding.root.context, colorRes))
            binding.tvStatus.setBackgroundResource(
                when (sms.status) {
                    SmsStatus.SENT -> R.drawable.badge_sent
                    SmsStatus.FAILED -> R.drawable.badge_failed
                    else -> R.drawable.badge_pending
                }
            )
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<SmsEntity>() {
            override fun areItemsTheSame(a: SmsEntity, b: SmsEntity) = a.id == b.id
            override fun areContentsTheSame(a: SmsEntity, b: SmsEntity) = a == b
        }
    }
}
