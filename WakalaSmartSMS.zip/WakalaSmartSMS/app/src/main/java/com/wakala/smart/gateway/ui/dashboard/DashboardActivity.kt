package com.wakala.smart.gateway.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.wakala.smart.gateway.R
import com.wakala.smart.gateway.databinding.ActivityDashboardBinding
import com.wakala.smart.gateway.service.SmsListenerService
import com.wakala.smart.gateway.sync.SmsSyncWorker
import com.wakala.smart.gateway.ui.logs.LogsActivity
import com.wakala.smart.gateway.ui.setup.SetupActivity
import com.wakala.smart.gateway.utils.SecurityUtils
import java.text.SimpleDateFormat
import java.util.*

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        SmsListenerService.start(this)
        setupObservers()
        setupClickListeners()
        loadDeviceInfo()
    }

    private fun setupObservers() {
        viewModel.totalCount.observe(this) {
            binding.tvSmsTotal.text = it.toString()
        }
        viewModel.sentCount.observe(this) {
            binding.tvSmsSent.text = it.toString()
        }
        viewModel.pendingCount.observe(this) {
            binding.tvSmsPending.text = it.toString()
        }
        viewModel.failedCount.observe(this) {
            binding.tvSmsFailed.text = it.toString()
        }
        viewModel.lastSyncTime.observe(this) { ts ->
            if (ts != null && ts > 0) {
                val fmt = SimpleDateFormat("dd MMM yyyy HH:mm:ss", Locale.getDefault())
                binding.tvLastSync.text = fmt.format(Date(ts))
            } else {
                binding.tvLastSync.text = getString(R.string.never_synced)
            }
        }
        viewModel.serviceRunning.observe(this) { running ->
            binding.tvConnectionStatus.text = if (running)
                getString(R.string.status_connected)
            else
                getString(R.string.status_disconnected)
            binding.tvConnectionStatus.setTextColor(
                if (running) getColor(R.color.status_sent)
                else getColor(R.color.status_failed)
            )
            binding.viewStatusDot.setBackgroundResource(
                if (running) R.drawable.dot_green else R.drawable.dot_red
            )
        }
    }

    private fun setupClickListeners() {
        binding.btnSyncNow.setOnClickListener {
            SmsSyncWorker.scheduleImmediateSync(this)
            android.widget.Toast.makeText(this, "Sync triggered", android.widget.Toast.LENGTH_SHORT).show()
        }
        binding.btnViewLogs.setOnClickListener {
            startActivity(Intent(this, LogsActivity::class.java))
        }
    }

    private fun loadDeviceInfo() {
        binding.tvAgentId.text = viewModel.agentId.ifBlank { "—" }
        binding.tvPhoneNumber.text = viewModel.phoneNumber.ifBlank { "—" }
        binding.tvDeviceId.text = viewModel.deviceId
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshStatus()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_dashboard, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SetupActivity::class.java))
                true
            }
            R.id.action_disconnect -> {
                SecurityUtils.clearAll(this)
                SmsListenerService.stop(this)
                SmsSyncWorker.cancelAll(this)
                startActivity(Intent(this, SetupActivity::class.java))
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
