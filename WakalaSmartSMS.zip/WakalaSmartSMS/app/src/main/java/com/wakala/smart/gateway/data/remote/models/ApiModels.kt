package com.wakala.smart.gateway.data.remote.models

import com.google.gson.annotations.SerializedName

data class SmsPayload(
    @SerializedName("sender") val sender: String,
    @SerializedName("message") val message: String,
    @SerializedName("timestamp") val timestamp: Long,
    @SerializedName("device_id") val deviceId: String,
    @SerializedName("agent_id") val agentId: String,
    @SerializedName("sms_id") val smsId: Int
)

data class ApiResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?,
    @SerializedName("data") val data: Any?
)

data class BatchSmsPayload(
    @SerializedName("messages") val messages: List<SmsPayload>,
    @SerializedName("device_id") val deviceId: String,
    @SerializedName("agent_id") val agentId: String
)
