package com.wakala.smart.gateway.utils

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import java.util.Base64

object SecurityUtils {

    private const val SECURE_PREFS_FILE = "wakala_secure_prefs"
    private const val KEY_API_TOKEN = "api_token"
    private const val KEY_AGENT_ID = "agent_id"
    private const val KEY_PHONE_NUMBER = "phone_number"
    private const val KEY_DB_PASSPHRASE = "db_passphrase"
    private const val KEY_IS_SETUP_COMPLETE = "is_setup_complete"

    private fun getEncryptedPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        return EncryptedSharedPreferences.create(
            context,
            SECURE_PREFS_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun getDatabasePassphrase(context: Context): String {
        val prefs = getEncryptedPrefs(context)
        var passphrase = prefs.getString(KEY_DB_PASSPHRASE, null)
        if (passphrase == null) {
            val bytes = ByteArray(32)
            SecureRandom().nextBytes(bytes)
            passphrase = Base64.getEncoder().encodeToString(bytes)
            prefs.edit().putString(KEY_DB_PASSPHRASE, passphrase).apply()
        }
        return passphrase
    }

    fun saveApiToken(context: Context, token: String) {
        getEncryptedPrefs(context).edit().putString(KEY_API_TOKEN, token).apply()
    }

    fun getApiToken(context: Context): String? {
        return getEncryptedPrefs(context).getString(KEY_API_TOKEN, null)
    }

    fun getBearerToken(context: Context): String {
        val token = getApiToken(context) ?: ""
        return "Bearer $token"
    }

    fun saveAgentId(context: Context, agentId: String) {
        getEncryptedPrefs(context).edit().putString(KEY_AGENT_ID, agentId).apply()
    }

    fun getAgentId(context: Context): String {
        return getEncryptedPrefs(context).getString(KEY_AGENT_ID, "") ?: ""
    }

    fun savePhoneNumber(context: Context, phone: String) {
        getEncryptedPrefs(context).edit().putString(KEY_PHONE_NUMBER, phone).apply()
    }

    fun getPhoneNumber(context: Context): String {
        return getEncryptedPrefs(context).getString(KEY_PHONE_NUMBER, "") ?: ""
    }

    fun setSetupComplete(context: Context, complete: Boolean) {
        getEncryptedPrefs(context).edit().putBoolean(KEY_IS_SETUP_COMPLETE, complete).apply()
    }

    fun isSetupComplete(context: Context): Boolean {
        return getEncryptedPrefs(context).getBoolean(KEY_IS_SETUP_COMPLETE, false)
    }

    fun getDeviceId(context: Context): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown_device"
    }

    fun clearAll(context: Context) {
        getEncryptedPrefs(context).edit().clear().apply()
    }
}
