package com.wakala.smart.gateway.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.wakala.smart.gateway.data.SmsRepository
import com.wakala.smart.gateway.utils.SecurityUtils

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SmsRepository(application)

    val totalCount: LiveData<Int> = repository.getTotalCount()
    val sentCount: LiveData<Int> = repository.getSentCount()
    val pendingCount: LiveData<Int> = repository.getPendingCount()
    val failedCount: LiveData<Int> = repository.getFailedCount()
    val lastSyncTime: LiveData<Long?> = repository.getLastSyncTime()

    val agentId: String get() = SecurityUtils.getAgentId(getApplication())
    val phoneNumber: String get() = SecurityUtils.getPhoneNumber(getApplication())
    val deviceId: String get() = SecurityUtils.getDeviceId(getApplication())

    private val _serviceRunning = MutableLiveData(true)
    val serviceRunning: LiveData<Boolean> = _serviceRunning

    fun refreshStatus() {
        _serviceRunning.value = SecurityUtils.isSetupComplete(getApplication())
    }
}
