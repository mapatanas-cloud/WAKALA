package com.wakala.smart.gateway.ui.setup

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.wakala.smart.gateway.utils.SecurityUtils

class SetupViewModel(application: Application) : AndroidViewModel(application) {

    private val _saveResult = MutableLiveData<SaveResult>()
    val saveResult: LiveData<SaveResult> = _saveResult

    private val _agentId = MutableLiveData<String>()
    val agentId: LiveData<String> = _agentId

    private val _phoneNumber = MutableLiveData<String>()
    val phoneNumber: LiveData<String> = _phoneNumber

    init {
        loadSavedData()
    }

    private fun loadSavedData() {
        val context = getApplication<Application>()
        _agentId.value = SecurityUtils.getAgentId(context)
        _phoneNumber.value = SecurityUtils.getPhoneNumber(context)
    }

    fun saveAndConnect(agentId: String, phoneNumber: String, apiKey: String) {
        val context = getApplication<Application>()

        if (agentId.isBlank()) {
            _saveResult.value = SaveResult.Error("Agent ID is required")
            return
        }
        if (phoneNumber.isBlank()) {
            _saveResult.value = SaveResult.Error("Phone number is required")
            return
        }
        if (apiKey.isBlank()) {
            _saveResult.value = SaveResult.Error("API Key is required")
            return
        }

        SecurityUtils.saveAgentId(context, agentId.trim())
        SecurityUtils.savePhoneNumber(context, phoneNumber.trim())
        SecurityUtils.saveApiToken(context, apiKey.trim())
        SecurityUtils.setSetupComplete(context, true)

        _saveResult.value = SaveResult.Success
    }

    fun isSetupComplete(): Boolean {
        return SecurityUtils.isSetupComplete(getApplication())
    }

    sealed class SaveResult {
        object Success : SaveResult()
        data class Error(val message: String) : SaveResult()
    }
}
