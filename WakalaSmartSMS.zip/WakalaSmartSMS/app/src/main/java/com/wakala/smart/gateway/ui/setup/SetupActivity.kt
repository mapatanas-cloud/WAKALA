package com.wakala.smart.gateway.ui.setup

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.wakala.smart.gateway.databinding.ActivitySetupBinding
import com.wakala.smart.gateway.service.SmsListenerService
import com.wakala.smart.gateway.sync.SmsSyncWorker
import com.wakala.smart.gateway.ui.dashboard.DashboardActivity

class SetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetupBinding
    private val viewModel: SetupViewModel by viewModels()

    private val requiredPermissions = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.READ_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            proceedWithSave()
        } else {
            Toast.makeText(this, "SMS permissions are required for this app to work", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // If already set up, go directly to dashboard
        if (viewModel.isSetupComplete()) {
            navigateToDashboard()
            return
        }

        setupObservers()
        setupClickListeners()
        populateSavedData()
    }

    private fun setupObservers() {
        viewModel.saveResult.observe(this) { result ->
            binding.progressBar.visibility = View.GONE
            binding.btnConnect.isEnabled = true

            when (result) {
                is SetupViewModel.SaveResult.Success -> {
                    SmsListenerService.start(this)
                    SmsSyncWorker.schedulePeriodicSync(this)
                    navigateToDashboard()
                }
                is SetupViewModel.SaveResult.Error -> {
                    Toast.makeText(this, result.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnConnect.setOnClickListener {
            val agentId = binding.etAgentId.text.toString()
            val phone = binding.etPhoneNumber.text.toString()
            val apiKey = binding.etApiKey.text.toString()

            if (hasRequiredPermissions()) {
                binding.progressBar.visibility = View.VISIBLE
                binding.btnConnect.isEnabled = false
                viewModel.saveAndConnect(agentId, phone, apiKey)
            } else {
                permissionLauncher.launch(requiredPermissions)
            }
        }
    }

    private fun populateSavedData() {
        viewModel.agentId.observe(this) { binding.etAgentId.setText(it) }
        viewModel.phoneNumber.observe(this) { binding.etPhoneNumber.setText(it) }
    }

    private fun hasRequiredPermissions(): Boolean {
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun proceedWithSave() {
        val agentId = binding.etAgentId.text.toString()
        val phone = binding.etPhoneNumber.text.toString()
        val apiKey = binding.etApiKey.text.toString()
        binding.progressBar.visibility = View.VISIBLE
        binding.btnConnect.isEnabled = false
        viewModel.saveAndConnect(agentId, phone, apiKey)
    }

    private fun navigateToDashboard() {
        startActivity(Intent(this, DashboardActivity::class.java))
        finish()
    }
}
