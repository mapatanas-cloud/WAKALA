package com.wakala.smart.gateway.data.remote.api

import com.wakala.smart.gateway.data.remote.models.ApiResponse
import com.wakala.smart.gateway.data.remote.models.SmsPayload
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface WakalaApiService {

    @POST("/api/sms-receive")
    suspend fun sendSms(
        @Header("Authorization") authToken: String,
        @Body payload: SmsPayload
    ): Response<ApiResponse>
}
