package com.wakala.smart.gateway.data

import android.content.Context
import android.util.Log
import com.wakala.smart.gateway.data.local.AppDatabase
import com.wakala.smart.gateway.data.local.entities.SmsEntity
import com.wakala.smart.gateway.data.local.entities.SmsStatus
import com.wakala.smart.gateway.data.remote.api.RetrofitClient
import com.wakala.smart.gateway.data.remote.models.SmsPayload
import com.wakala.smart.gateway.utils.SecurityUtils

class SmsRepository(private val context: Context) {

    private val smsDao = AppDatabase.getInstance(context).smsDao()
    private val apiService = RetrofitClient.apiService

    companion object {
        private const val TAG = "SmsRepository"
    }

    // ─── Local DB ────────────────────────────────────────────────────────────

    fun getAllSms() = smsDao.getAllSms()

    fun getRecentSms(limit: Int = 100) = smsDao.getRecentSms(limit)

    fun getTotalCount() = smsDao.getTotalCount()

    fun getSentCount() = smsDao.getCountByStatus(SmsStatus.SENT)

    fun getPendingCount() = smsDao.getCountByStatus(SmsStatus.PENDING)

    fun getFailedCount() = smsDao.getCountByStatus(SmsStatus.FAILED)

    fun getLastSyncTime() = smsDao.getLastSyncTime()

    suspend fun saveSms(sender: String, message: String, timestamp: Long): Long {
        val entity = SmsEntity(
            sender = sender,
            message = message,
            timestamp = timestamp,
            status = SmsStatus.PENDING
        )
        return smsDao.insert(entity)
    }

    suspend fun getPendingSms(): List<SmsEntity> = smsDao.getPendingSms()

    suspend fun getFailedSms(): List<SmsEntity> = smsDao.getFailedSms()

    suspend fun updateStatus(id: Int, status: String) = smsDao.updateStatus(id, status)

    // ─── Remote API ──────────────────────────────────────────────────────────

    suspend fun syncSingleSms(sms: SmsEntity): Boolean {
        return try {
            val payload = SmsPayload(
                sender = sms.sender,
                message = sms.message,
                timestamp = sms.timestamp,
                deviceId = SecurityUtils.getDeviceId(context),
                agentId = SecurityUtils.getAgentId(context),
                smsId = sms.id
            )

            val token = SecurityUtils.getBearerToken(context)
            val response = apiService.sendSms(token, payload)

            if (response.isSuccessful && response.body()?.success == true) {
                smsDao.updateStatus(sms.id, SmsStatus.SENT)
                Log.d(TAG, "SMS ${sms.id} synced successfully")
                true
            } else {
                val error = response.errorBody()?.string() ?: "Unknown API error"
                smsDao.updateStatusWithError(sms.id, SmsStatus.FAILED, error)
                Log.w(TAG, "SMS ${sms.id} sync failed: $error")
                false
            }
        } catch (e: Exception) {
            smsDao.updateStatusWithError(sms.id, SmsStatus.FAILED, e.message ?: "Exception")
            Log.e(TAG, "Exception syncing SMS ${sms.id}", e)
            false
        }
    }

    suspend fun syncAllPending(): Pair<Int, Int> {
        val pending = getPendingSms()
        var successCount = 0
        var failCount = 0

        for (sms in pending) {
            smsDao.updateStatus(sms.id, SmsStatus.SYNCING)
            if (syncSingleSms(sms)) successCount++ else failCount++
        }

        Log.d(TAG, "Sync complete: $successCount sent, $failCount failed")
        return Pair(successCount, failCount)
    }

    suspend fun retryFailed(): Pair<Int, Int> {
        val failed = getFailedSms().filter { it.retryCount < 3 }
        var successCount = 0
        var failCount = 0

        for (sms in failed) {
            if (syncSingleSms(sms)) successCount++ else failCount++
        }
        return Pair(successCount, failCount)
    }

    suspend fun cleanOldMessages(olderThanDays: Int = 30) {
        val cutoff = System.currentTimeMillis() - (olderThanDays * 24 * 60 * 60 * 1000L)
        smsDao.deleteOldSentMessages(olderThan = cutoff)
    }
}
