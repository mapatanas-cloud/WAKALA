package com.wakala.smart.gateway.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.wakala.smart.gateway.service.SmsListenerService
import com.wakala.smart.gateway.sync.SmsSyncWorker
import com.wakala.smart.gateway.utils.SecurityUtils

class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        Log.d(TAG, "Boot/update received — restarting services")

        if (!SecurityUtils.isSetupComplete(context)) {
            Log.w(TAG, "Setup not complete — skipping auto-start")
            return
        }

        // Start foreground service
        SmsListenerService.start(context)

        // Schedule periodic sync
        SmsSyncWorker.schedulePeriodicSync(context)

        Log.d(TAG, "Services restarted after boot")
    }
}
