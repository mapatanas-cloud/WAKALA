package com.wakala.smart.gateway.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.wakala.smart.gateway.data.SmsRepository
import com.wakala.smart.gateway.sync.SmsSyncWorker
import com.wakala.smart.gateway.utils.SecurityUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "SmsReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        // Only process if setup is complete
        if (!SecurityUtils.isSetupComplete(context)) {
            Log.w(TAG, "Setup not complete — skipping SMS processing")
            return
        }

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        // Group message parts by originating address
        val grouped = messages.groupBy { it.originatingAddress ?: "Unknown" }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = SmsRepository(context)

                for ((sender, parts) in grouped) {
                    val fullMessage = parts.joinToString("") { it.messageBody ?: "" }
                    val timestamp = parts.firstOrNull()?.timestampMillis
                        ?: System.currentTimeMillis()

                    Log.d(TAG, "SMS received from $sender: ${fullMessage.take(50)}...")

                    repository.saveSms(
                        sender = sender,
                        message = fullMessage,
                        timestamp = timestamp
                    )
                }

                // Trigger immediate sync
                SmsSyncWorker.scheduleImmediateSync(context)

            } catch (e: Exception) {
                Log.e(TAG, "Error processing incoming SMS", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
