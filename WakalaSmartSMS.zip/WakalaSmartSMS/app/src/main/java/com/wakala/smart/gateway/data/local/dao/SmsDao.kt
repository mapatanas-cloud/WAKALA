package com.wakala.smart.gateway.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.wakala.smart.gateway.data.local.entities.SmsEntity
import com.wakala.smart.gateway.data.local.entities.SmsStatus

@Dao
interface SmsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(sms: SmsEntity): Long

    @Update
    suspend fun update(sms: SmsEntity)

    @Delete
    suspend fun delete(sms: SmsEntity)

    @Query("SELECT * FROM sms_messages ORDER BY timestamp DESC")
    fun getAllSms(): LiveData<List<SmsEntity>>

    @Query("SELECT * FROM sms_messages ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentSms(limit: Int = 100): LiveData<List<SmsEntity>>

    @Query("SELECT * FROM sms_messages WHERE status = :status ORDER BY timestamp ASC")
    suspend fun getPendingSms(status: String = SmsStatus.PENDING): List<SmsEntity>

    @Query("SELECT * FROM sms_messages WHERE status = :status ORDER BY timestamp ASC")
    suspend fun getFailedSms(status: String = SmsStatus.FAILED): List<SmsEntity>

    @Query("UPDATE sms_messages SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Int, status: String)

    @Query("UPDATE sms_messages SET status = :status, errorMessage = :error, retryCount = retryCount + 1 WHERE id = :id")
    suspend fun updateStatusWithError(id: Int, status: String, error: String)

    @Query("SELECT COUNT(*) FROM sms_messages")
    fun getTotalCount(): LiveData<Int>

    @Query("SELECT COUNT(*) FROM sms_messages WHERE status = :status")
    fun getCountByStatus(status: String): LiveData<Int>

    @Query("SELECT MAX(timestamp) FROM sms_messages WHERE status = :status")
    fun getLastSyncTime(status: String = SmsStatus.SENT): LiveData<Long?>

    @Query("DELETE FROM sms_messages WHERE status = :status AND timestamp < :olderThan")
    suspend fun deleteOldSentMessages(status: String = SmsStatus.SENT, olderThan: Long)

    @Query("SELECT * FROM sms_messages WHERE id = :id")
    suspend fun getById(id: Int): SmsEntity?
}
