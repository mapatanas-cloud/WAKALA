package com.wakala.smart.gateway.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sms_messages")
data class SmsEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val sender: String,
    val message: String,
    val timestamp: Long,
    val status: String = SmsStatus.PENDING,
    val retryCount: Int = 0,
    val errorMessage: String? = null
)

object SmsStatus {
    const val PENDING = "pending"
    const val SENT = "sent"
    const val FAILED = "failed"
    const val SYNCING = "syncing"
}
