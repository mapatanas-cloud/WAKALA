package com.wakala.smart.gateway

import android.app.Application
import com.wakala.smart.gateway.sync.SmsSyncWorker
import com.wakala.smart.gateway.utils.SecurityUtils

class WakalaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (SecurityUtils.isSetupComplete(this)) {
            SmsSyncWorker.schedulePeriodicSync(this)
        }
    }
}
