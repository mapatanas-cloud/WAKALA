package com.wakala.smart.gateway.ui.logs

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.wakala.smart.gateway.data.SmsRepository

class LogsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SmsRepository(application)
    val smsList = repository.getRecentSms(200)
}
