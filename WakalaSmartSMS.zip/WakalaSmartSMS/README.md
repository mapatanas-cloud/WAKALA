# WakalaSmartSMS Gateway

An Android SMS gateway app that intercepts incoming SMS messages and automatically forwards them to the Wakala Smart platform API.

---

## Features

- Auto-intercept all incoming SMS messages
- Local encrypted database (SQLCipher + Room)
- Background sync via WorkManager (exponential retry)
- Foreground service to keep listener alive across reboots
- Encrypted API key storage (EncryptedSharedPreferences)
- SMS status tracking: Pending → Sent / Failed
- Dashboard with live stats
- Full SMS log viewer

---

## Build Instructions

### Option 1 — Android Studio (Easiest)

1. Open **Android Studio** (download from https://developer.android.com/studio)
2. Select **Open** and choose the `WakalaSmartSMS` folder
3. Wait for Gradle sync to complete (~2–5 min first time)
4. Click **Build → Build Bundle(s)/APK(s) → Build APK(s)**
5. Find the APK at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```
6. Transfer to your Android device and install

### Option 2 — Command Line

```bash
# Requires: Java 17+, Android SDK with ANDROID_HOME set
chmod +x gradlew
./gradlew assembleDebug

# APK location:
# app/build/outputs/apk/debug/app-debug.apk
```

### Option 3 — GitHub Actions (Zero setup required)

1. Push this project to a GitHub repository
2. Go to **Actions** tab in your repo
3. The workflow runs automatically on every push
4. Download the APK from **Actions → latest run → Artifacts**

---

## First-Time App Setup

1. Install the APK on your Android device
2. Open the app — you'll see the **Setup** screen
3. Enter:
   - **Agent ID** — your Wakala agent identifier
   - **Phone Number** — the SIM number in this device
   - **API Key** — your Wakala platform API key
4. Tap **Connect & Activate**
5. Grant SMS and notification permissions when prompted
6. The dashboard will show your connection status

---

## Architecture

```
WakalaSmartSMS/
├── data/
│   ├── local/              # Room DB + SQLCipher encryption
│   │   ├── AppDatabase.kt
│   │   ├── dao/SmsDao.kt
│   │   └── entities/SmsEntity.kt
│   ├── remote/             # Retrofit API client
│   │   ├── api/WakalaApiService.kt
│   │   ├── api/RetrofitClient.kt
│   │   └── models/ApiModels.kt
│   └── SmsRepository.kt   # Single source of truth
├── receiver/
│   ├── SmsReceiver.kt      # Intercepts incoming SMS (priority 999)
│   └── BootReceiver.kt     # Restarts service after reboot
├── service/
│   └── SmsListenerService.kt  # Foreground service (START_STICKY)
├── sync/
│   └── SmsSyncWorker.kt   # WorkManager + exponential backoff
├── ui/
│   ├── setup/             # Agent ID + API key configuration
│   ├── dashboard/         # Live stats and controls
│   └── logs/              # Full SMS log with status badges
└── utils/
    └── SecurityUtils.kt   # EncryptedSharedPreferences wrapper
```

---

## API Integration

**Endpoint:** `POST https://wakala-smart-sync.base44.app/api/sms-receive`

**Payload:**
```json
{
  "sender": "+255712345678",
  "message": "SMS body text",
  "timestamp": 1713456789000,
  "device_id": "abc123def456",
  "agent_id": "AGENT_001",
  "sms_id": 42
}
```

**Headers:**
```
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
```

---

## Security

| Feature | Implementation |
|---|---|
| Database encryption | SQLCipher with auto-generated 256-bit key |
| API key storage | AES256-GCM EncryptedSharedPreferences |
| DB key storage | AES256-GCM EncryptedSharedPreferences |
| No cloud backup | Sensitive data excluded from backup |
| Device binding | Android ANDROID_ID bound to each request |

---

## Permissions Required

| Permission | Purpose |
|---|---|
| `RECEIVE_SMS` | Intercept incoming SMS |
| `READ_SMS` | Read SMS content |
| `INTERNET` | Sync to Wakala API |
| `ACCESS_NETWORK_STATE` | Check connectivity before sync |
| `FOREGROUND_SERVICE` | Keep listener alive |
| `RECEIVE_BOOT_COMPLETED` | Auto-start after reboot |
| `WAKE_LOCK` | Prevent CPU sleep during sync |
| `POST_NOTIFICATIONS` | Show foreground service notification |

---

## Requirements

- Android 7.0+ (API 24+)
- SMS permissions must be granted
- Active internet connection for sync (SMS are stored offline when no internet)
